# Identity frontend

To start in development mode run

```shell
yarn dev
```

