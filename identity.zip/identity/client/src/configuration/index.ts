export const baseUrl = "/identity";

export const apiBaseUrl = "/v2";

export const docsUrl = "https://docs.camunda.io";
