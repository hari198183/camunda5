/// <reference types="vite/client" />

declare module "@carbon/react";
declare module "@carbon/react/lib/components/ListBox";
declare module "@carbon/react/icons";
declare module "@carbon/themes";
declare module "@carbon/motion";
