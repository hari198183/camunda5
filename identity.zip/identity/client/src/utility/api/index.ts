export * from "./hooks";

export type SearchResponse<R> = {
  items: R[];
};
