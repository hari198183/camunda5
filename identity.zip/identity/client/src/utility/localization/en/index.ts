import components from "./components.json";
import permissions from "./permissions.json";

export default {
  components,
  permissions,
};
